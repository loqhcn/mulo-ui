import ElInputNumber from './input-number';

/* istanbul ignore next */
ElInputNumber.install = function(Vue) {
  Vue.component(ElInputNumber.name, ElInputNumber);
};
 
export default ElInputNumber;
