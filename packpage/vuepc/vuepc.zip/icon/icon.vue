<template>
  <i class="fa">图标</i>
</template>

<script>
  export default {
    name:'o-icon'
  }
</script>

<style lang="scss" scoped>
  
</style>